<!DOCTYPE html>
<html>
<body>

  <table>
    <thead>
      <tr>
        <?php foreach ($variable as $key => $value) {
          # code...
        } ?>
      </tr>
    </thead>
    <tbody>

    </tbody>
    <!-- <tr>
      <td>Nama</td>
      <td><?php echo $nama ?></td>
    </tr>
    <tr>
      <td>Detail</td>
      <td><?php echo $detail ?></td>
    </tr>
    <tr>
      <td>Other Details</td>
      <td><?php echo $other ?></td>
    </tr> -->
  </table>

</body>
</html>
